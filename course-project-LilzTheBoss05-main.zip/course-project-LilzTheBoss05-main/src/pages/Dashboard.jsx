import { useEffect, useState } from 'react';
import TimelineItem from '../components/TimelineItem';
import TaskForm from '../components/TaskForm';

const Dashboard = ({ tasks, setTasks, inbox }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Helper function to convert time string (e.g., "7:30 am") to minutes since midnight
  const parseTimeToMinutes = (timeStr) => {
    if (!timeStr) return 0;
    const [time, modifier] = timeStr.toLowerCase().split(' ');
    let [hours, minutes] = time.split(':').map(Number);

    if (modifier === 'pm' && hours !== 12) hours += 12;
    if (modifier === 'am' && hours === 12) hours = 0;

    return (hours * 60) + minutes;
  };

  // Create a sorted copy of tasks so we don't mutate the original state
  const sortedTasks = [...tasks].sort((a, b) => {
    return parseTimeToMinutes(a.time) - parseTimeToMinutes(b.time);
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        await new Promise(res => setTimeout(res, 1000));
        
        if (tasks.length === 0) {
          setTasks([
            { id: '1', title: 'wake up', time: '7:30 am', note: 'morning vibes' },
            { id: '2', title: 'csci class', time: '12:30 pm', note: 'bring laptop' },
            { id: '3', title: 'therapy', time: '2:00 pm', note: 'be honest today' }
          ]);
        }
      } catch (err) {
        setError('dang, couldnt load your schedule...');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [setTasks, tasks.length]);

  if (loading) return (
    <div className="flex justify-center mt-20 italic text-zinc-500 animate-pulse">
      getting your day ready...
    </div>
  );

  if (error) return <p className="text-red-400 text-center mt-10">{error}</p>;

  return (
    <section className="animate-in fade-in duration-500">
      {inbox && inbox.length > 0 && (
        <div className="mb-10">
          <h2 className="text-zinc-500 text-[10px] font-bold uppercase tracking-widest mb-4">
            unscheduled (inbox)
          </h2>
          <div className="flex gap-3 overflow-x-auto pb-4 no-scrollbar">
            {inbox.map(item => (
              <div 
                key={item.id} 
                className="bg-zinc-800 p-4 rounded-3xl min-w-[140px] border border-zinc-700/50 hover:border-emerald-500/50 transition-colors"
              >
                <p className="text-emerald-400 text-[10px] font-mono mb-1">{item.duration}</p>
                <h4 className="font-bold text-sm truncate">{item.title}</h4>
              </div>
            ))}
          </div>
        </div>
      )}

      <TaskForm onAddTask={async (newTask) => {
        try {
          const response = await fetch('/api/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...newTask, date: selectedDate })
          });
          if (response.ok) {
            const createdTask = await response.json();
            setTasks([...tasks, createdTask]);
          } else {
            console.error('Failed to create task');
          }
        } catch (error) {
          console.error('Error creating task:', error);
        }
      }} />
      
      <div className="mt-12">
        <h2 className="text-zinc-500 text-[10px] font-bold uppercase tracking-widest mb-8">
          today's timeline
        </h2>
        <div className="space-y-2">
          {/* Mapping through sortedTasks instead of original tasks */}
          {sortedTasks.map(t => (
            <TimelineItem key={t.id} task={t} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Dashboard;