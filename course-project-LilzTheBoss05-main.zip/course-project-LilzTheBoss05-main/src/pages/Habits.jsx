import { useState, useEffect } from 'react';
import HabitCard from '../components/HabitCard';

const Habits = () => {
  const [habits, setHabits] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // faking an api call to get the habits
    const timer = setTimeout(() => {
      setHabits([
        { id: 1, name: 'drink water', type: 'increase' },
        { id: 2, name: 'smoking', type: 'decrease' },
        { id: 3, name: 'stretching', type: 'increase' }
      ]);
      setLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  if (loading) return <p className="text-center mt-10">loading your habits...</p>;

  return (
    <div className="animate-in slide-in-from-bottom-4 duration-500">
      <h1 className="text-3xl font-bold mb-6">my habits</h1>
      {habits.map(h => (
        <HabitCard key={h.id} habit={h} />
      ))}
    </div>
  );
};

export default Habits;