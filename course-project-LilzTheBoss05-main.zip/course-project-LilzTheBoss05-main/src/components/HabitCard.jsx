import { useState } from 'react';

const HabitCard = ({ habit }) => {
  // state to track the count locally
  const [count, setCount] = useState(0);

  return (
    <div className="bg-zinc-800 p-5 rounded-3xl mb-4 flex items-center justify-between border border-zinc-700">
      <div>
        <h3 className="text-xl font-bold">{habit.name}</h3>
        <p className="text-zinc-400 text-sm">
          goal: {habit.type === 'increase' ? 'do more' : 'do less'}
        </p>
      </div>

      <div className="flex items-center gap-4">
        {/* button to decrease count */}
        <button 
          onClick={() => setCount(Math.max(0, count - 1))}
          className="w-10 h-10 rounded-full bg-zinc-700 flex items-center justify-center text-2xl"
        >
          -
        </button>
        
        <span className={`text-2xl font-mono ${habit.type === 'increase' ? 'text-emerald-400' : 'text-red-400'}`}>
          {count}
        </span>

        {/* button to increase count */}
        <button 
          onClick={() => setCount(count + 1)}
          className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-black font-bold text-2xl"
        >
          +
        </button>
      </div>
    </div>
  );
};

export default HabitCard;