import express from 'express';
import { getTasks, createTask, updateTask } from '../controllers/taskController.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

// these routes are protected, only accessible with a valid jwt 
router.use(protect);

router.get('/', getTasks);
router.post('/', createTask);

// new route to handle updates for specific tasks
// using :id so we know exactly which task to modify
router.put('/:id', updateTask);

export default router;