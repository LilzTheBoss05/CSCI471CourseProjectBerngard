import User from '../models/User.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

export const register = async (req, res) => {
  const { username, password } = req.body;
  try {
    // role is set to 'user' by default, never trusted from body
    const user = await User.create({ username, password, role: 'user' });
    res.status(201).json({ message: 'user registered' });
  } catch (err) {
    res.status(400).json({ message: 'registration failed' });
  }
};

export const login = async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  
  if (user && (await bcrypt.compare(password, user.password))) {
    // return signed jwt 
    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
  } else {
    res.status(401).json({ message: 'invalid credentials' });
  }
};