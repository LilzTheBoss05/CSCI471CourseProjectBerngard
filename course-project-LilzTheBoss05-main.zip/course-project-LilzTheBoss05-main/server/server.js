import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import authRoutes from './routes/authRoutes.js';
import taskRoutes from './routes/taskRoutes.js';
import recurringTaskRoutes from './routes/recurringTaskRoutes.js';

const app = express();

// security middleware
app.use(helmet()); 
app.use(cors({ origin: 'http://localhost:5173' })); // make sure this matches my port
app.use(express.json()); // for parsing incoming body data

// routes
app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/recurring-tasks', recurringTaskRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`server running on port ${PORT}`));